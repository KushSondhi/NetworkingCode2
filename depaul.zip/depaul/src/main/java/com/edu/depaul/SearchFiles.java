package com.edu.depaul;

import java.util.HashSet;
import java.util.Set;

public class SearchFiles {

	public static void main(String[] args) {

		Set<String> setValues = new HashSet<String>();
		setValues.add("Kush");
		setValues.add("Sondhi");
		setValues.add("kush");

		System.out.println(setValues);

	}

}
